# orcapcp

Python bindings for the **OrCaPCP** parallel-coordinates visualization (Jupyter / anywidget).

## Install (from repository)

1. From the **repository root** (`cxpcp/`), build the notebook frontend:

   ```bash
   npm install
   npm run build:notebook
   ```

2. Install the package in editable mode (include Jupyter widget dependencies so sliders render):

   ```bash
   pip install -e "./pkg[notebook]"
   ```

See [`docs/instructions.md`](../docs/instructions.md) (from repo root) for full local testing and JupyterLab setup.

## Stability (0.x)

Minor releases may change Python APIs or widget traits; pin `orcapcp==x.y.z` in reproducible notebooks.
