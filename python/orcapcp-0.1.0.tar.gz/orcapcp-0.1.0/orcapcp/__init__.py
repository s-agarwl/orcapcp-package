"""OrCaPCP Jupyter widget: parallel coordinates visualization."""

from orcapcp.api import orcapcp
from orcapcp.display import on_selection, selected_df, show
from orcapcp.widget import ParallelCoordsWidget

__all__ = ["ParallelCoordsWidget", "orcapcp", "show", "on_selection", "selected_df"]
__version__ = "0.1.0"
