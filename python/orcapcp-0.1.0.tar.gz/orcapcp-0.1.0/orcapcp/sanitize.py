"""
Ensure widget traits are JSON-serializable.

ipywidgets sends synced state over Jupyter comms; values must round-trip through
JSON. Pandas/numpy scalars (e.g. numpy.int64) often break serialization and
surface as browser errors such as "Exception opening new comm".
"""

from __future__ import annotations

import json
import math
from typing import Any

import pandas as pd


def json_safe_rows(data: pd.DataFrame | list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert tabular data to plain Python types (ints, floats, str, None, bool)."""
    if isinstance(data, pd.DataFrame):
        if data.empty:
            return []
        return json.loads(data.to_json(orient="records", date_format="iso"))
    if isinstance(data, list):
        if not data:
            return []
        return json.loads(pd.DataFrame(data).to_json(orient="records", date_format="iso"))
    raise TypeError("data must be a pandas DataFrame or a list of dict rows")


def _json_default(o: object) -> object:
    if hasattr(o, "item") and callable(getattr(o, "item", None)):
        try:
            return o.item()  # numpy / pandas scalar
        except Exception:
            pass
    if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
        return None
    raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")


def json_safe_column_configs(configs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Deep-convert column config dicts to JSON-safe values."""
    if not configs:
        return []
    return json.loads(json.dumps(configs, default=_json_default))


def json_safe_exported_config(obj: dict[str, Any] | None) -> str:
    """
    Serialize a full OrCaPCP export dict for the notebook widget trait.

    Returns a JSON string, or \"\" when there is no hydratable snapshot
    (missing ``columns`` array or non-dict).
    """
    if not obj or not isinstance(obj, dict):
        return ""
    cols = obj.get("columns")
    if not isinstance(cols, list):
        return ""
    try:
        safe = json.loads(json.dumps(obj, default=_json_default))
    except TypeError:
        return ""
    return json.dumps(safe, ensure_ascii=False, separators=(",", ":"))
