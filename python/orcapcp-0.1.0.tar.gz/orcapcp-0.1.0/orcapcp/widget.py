"""anywidget bridge to the bundled notebook.mjs bundle."""

from __future__ import annotations

import os
import pathlib

import traitlets as t

import anywidget

from orcapcp._local_bundle_server import ensure_local_bundle_url

_STATIC = pathlib.Path(__file__).parent / "static" / "notebook.mjs"


def _resolve_esm() -> str | pathlib.Path:
    """
    Prefer a short http URL so widget state stays small (see _local_bundle_server).

    Override with:
    - ORCAPCP_ESM_URL — full URL to notebook.mjs (e.g. CDN).
    - ORCAPCP_EMBED_BUNDLE=1 — embed file contents in state (large; may break some UIs).
    """
    explicit = os.environ.get("ORCAPCP_ESM_URL", "").strip()
    if explicit:
        return explicit
    if os.environ.get("ORCAPCP_EMBED_BUNDLE") == "1":
        return _STATIC
    return ensure_local_bundle_url()


class ParallelCoordsWidget(anywidget.AnyWidget):
    """Interactive parallel-coordinates plot; pass tabular data via traits."""

    _esm = _resolve_esm()

    rows = t.List(t.Any()).tag(sync=True)
    column_configs = t.List(t.Any()).tag(sync=True)
    load_error = t.Unicode("").tag(sync=True)
    # Indices into the original input row order (0-based). Updated by the frontend on selection.
    selected_indices = t.List(t.Int(), default_value=[]).tag(sync=True)

    @t.default("rows")
    def _default_rows(self) -> list:
        return []

    @t.default("column_configs")
    def _default_column_configs(self) -> list:
        return []

    def __init__(self, *args, **kwargs):
        if not _STATIC.is_file():
            raise FileNotFoundError(
                f"Notebook bundle missing: {_STATIC}. "
                "From the repo root run: npm run build:notebook",
            )
        super().__init__(*args, **kwargs)
