"""
Serve pkg/orcapcp/static/ on 127.0.0.1 so _esm can be a short http(s) URL.

anywidget embeds Path-based _esm file *contents* in synced widget state (~3MB for
this app), which breaks comms in some frontends (Cursor/VS Code). Pointing _esm
at http://127.0.0.1:<port>/notebook.mjs keeps state small; the browser fetches JS.
"""

from __future__ import annotations

import os
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

_lock = threading.Lock()
_server: ThreadingHTTPServer | None = None
_public_url: str | None = None


def static_dir() -> Path:
    return Path(__file__).resolve().parent / "static"


def ensure_local_bundle_url(filename: str = "notebook.mjs") -> str:
    """Start a daemon server once; return URL to ``filename`` under static/."""
    global _server, _public_url
    with _lock:
        if _public_url is not None:
            return _public_url

        root = static_dir()
        target = root / filename
        if not target.is_file():
            raise FileNotFoundError(f"Missing widget bundle: {target}")

        class CORSHandler(SimpleHTTPRequestHandler):
            extensions_map = {
                **SimpleHTTPRequestHandler.extensions_map,
                ".js": "application/javascript",
                ".mjs": "application/javascript",
                ".css": "text/css",
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=str(root), **kwargs)

            def end_headers(self):
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
                super().end_headers()

            def log_message(self, fmt: str, *args) -> None:  # noqa: A003
                if os.environ.get("ORCAPCP_DEBUG_SERVER"):
                    super().log_message(fmt, *args)

        srv = ThreadingHTTPServer(("127.0.0.1", 0), CORSHandler)
        port = srv.server_address[1]
        t = threading.Thread(target=srv.serve_forever, daemon=True, name="orcapcp-bundle-http")
        t.start()
        _server = srv
        _public_url = f"http://127.0.0.1:{port}/{filename}"
        return _public_url
