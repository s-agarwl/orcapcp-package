"""Convenience helpers for notebooks."""

from __future__ import annotations

import os
import warnings
from typing import Any

import pandas as pd
from ipywidgets import Layout

from orcapcp.sanitize import json_safe_column_configs, json_safe_rows
from orcapcp.widget import ParallelCoordsWidget


def on_selection(
    widget: ParallelCoordsWidget,
    callback,
    *,
    run_immediately: bool = True,
):
    """
    Subscribe to selection changes (notebook -> Python).

    Parameters
    ----------
    widget
        A ``ParallelCoordsWidget`` instance.
    callback
        Callable that accepts the new selection indices: ``callback(indices: list[int])``.
    run_immediately
        If True (default), invoke callback once with the current selection.

    Returns
    -------
    unsubscribe
        Call the returned function to remove the observer.
    """

    def _handler(change):
        callback(list(change.get("new") or []))

    widget.observe(_handler, names=["selected_indices"])
    if run_immediately:
        callback(list(getattr(widget, "selected_indices", []) or []))

    def unsubscribe():
        try:
            widget.unobserve(_handler, names=["selected_indices"])
        except Exception:
            pass

    return unsubscribe


def selected_df(df: pd.DataFrame, widget: ParallelCoordsWidget) -> pd.DataFrame:
    """Convenience: return ``df.iloc[widget.selected_indices]``."""
    idx = list(getattr(widget, "selected_indices", []) or [])
    return df.iloc[idx]


def _maybe_ipython_display(widget: ParallelCoordsWidget) -> None:
    """Render the widget in Jupyter / VS Code notebooks (not just ``repr``)."""
    try:
        from IPython import get_ipython
        from IPython.display import display

        if get_ipython() is not None:
            display(widget)
    except Exception as e:
        if os.environ.get("ORCAPCP_DEBUG"):
            warnings.warn(f"orcapcp: IPython display() failed: {e!r}", stacklevel=2)


def show(
    df: pd.DataFrame,
    *,
    column_configs: list[dict[str, Any]] | None = None,
    height: str = "520px",
    width: str = "100%",
    **layout_kwargs: Any,
) -> ParallelCoordsWidget:
    """
    Display a DataFrame in the OrCaPCP widget.

    In Jupyter, prefer ``w = show(df, …)`` so the cell does not echo the return
    value as an extra line of text (see ``orcapcp()`` docstring).

    Parameters
    ----------
    df
        Rows become ``rows`` (records); column order follows ``df.columns``.
    column_configs
        Optional per-column metadata (``dataType``, ``hidden``, etc.). If omitted,
        types are inferred in the frontend.
    height, width
        Passed to ``ipywidgets.Layout`` together with ``layout_kwargs``.
    """
    layout = Layout(height=height, width=width, **layout_kwargs)
    w = ParallelCoordsWidget(
        rows=json_safe_rows(df),
        column_configs=json_safe_column_configs(list(column_configs or [])),
        layout=layout,
    )
    _maybe_ipython_display(w)
    return w
