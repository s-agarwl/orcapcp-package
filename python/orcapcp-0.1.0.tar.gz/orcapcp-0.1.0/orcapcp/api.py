"""Primary API: ``orcapcp(data, …)``."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
from ipywidgets import Layout

from orcapcp.display import _maybe_ipython_display
from orcapcp.sanitize import (
    json_safe_column_configs,
    json_safe_exported_config,
    json_safe_rows,
)
from orcapcp.widget import ParallelCoordsWidget


def _configs_from_json_obj(obj: Any) -> list[dict[str, Any]]:
    if obj is None:
        return []
    if isinstance(obj, list):
        return list(obj)
    if isinstance(obj, dict) and "columns" in obj:
        cols = obj["columns"]
        if isinstance(cols, list):
            return list(cols)
    return []


def _read_config_file_raw(path: str | Path) -> Any:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Config file not found: {p.resolve()}")
    return json.loads(p.read_text(encoding="utf-8"))


def _rows_from_data(data: pd.DataFrame | list[dict[str, Any]]) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return list(data)
    if hasattr(data, "to_dict"):
        return data.to_dict(orient="records")  # type: ignore[no-any-return]
    raise TypeError(
        "data must be a pandas DataFrame or a list of row dicts",
    )


def orcapcp(
    data: pd.DataFrame | list[dict[str, Any]],
    *,
    column_configs: list[dict[str, Any]] | None = None,
    config: dict[str, Any] | list[dict[str, Any]] | None = None,
    config_file: str | Path | None = None,
    height: str = "520px",
    width: str = "100%",
    **layout_kwargs: Any,
) -> ParallelCoordsWidget:
    """
    Show tabular data in the OrCaPCP parallel-coordinates widget.

    In a notebook, the widget is **displayed automatically** via IPython
    ``display()`` inside this function. Prefer ``w = orcapcp(df)`` so the cell
    does not *also* print the return value (which looks like a second
    ``<ParallelCoordsWidget …>`` line if the rich widget view does not render).

    Parameters
    ----------
    data
        ``pandas.DataFrame`` or list of row records (``list[dict]``).
    column_configs
        Optional list of per-column objects (``dataType``, ``hidden``, …).
        This overrides ``config`` and ``config_file`` when given.
    config
        Either a list of column configs, or a dict with a ``"columns"`` array
        (same shape as OrCaPCP dataset JSON / exported config).
    config_file
        Path to a JSON file: full **Download Config** export from the web app, or
        legacy ``{"columns": [ ... ]}`` / a raw array of column configs only.
    height, width
        Layout size; additional keys go to ``ipywidgets.Layout``.

    Priority
    --------
    ``column_configs`` (if passed) overrides ``config`` and ``config_file``.
    ``config`` overrides ``config_file`` when both are set.

    When ``column_configs`` is passed, or ``config`` is a plain list, the
    ``exported_config_json`` trait is left empty so the notebook does not hydrate
    from a snapshot that could disagree with the overridden column list.
    """
    loaded_file: Any = None
    if config_file is not None:
        loaded_file = _read_config_file_raw(config_file)

    resolved: list[dict[str, Any]] = []
    if loaded_file is not None:
        resolved = _configs_from_json_obj(loaded_file)
    if config is not None:
        if isinstance(config, list):
            resolved = list(config)
        else:
            resolved = _configs_from_json_obj(config)
    if column_configs is not None:
        resolved = list(column_configs)

    full_doc: dict[str, Any] | None = None
    if column_configs is None and not isinstance(config, list):
        if isinstance(config, dict):
            full_doc = config
        elif isinstance(loaded_file, dict):
            full_doc = loaded_file

    rows = json_safe_rows(_rows_from_data(data))
    resolved = json_safe_column_configs(resolved)
    exported_json = json_safe_exported_config(full_doc)
    layout = Layout(height=height, width=width, **layout_kwargs)
    w = ParallelCoordsWidget(
        rows=rows,
        column_configs=resolved,
        exported_config_json=exported_json,
        layout=layout,
    )
    _maybe_ipython_display(w)
    return w
